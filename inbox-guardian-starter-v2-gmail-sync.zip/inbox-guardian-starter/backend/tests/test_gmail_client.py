from app.services.gmail_client import _extract_links, _parse_from_header


def test_parse_from_header():
    name, email = _parse_from_header('Bank Security Team <alerts@example.com>')
    assert name == 'Bank Security Team'
    assert email == 'alerts@example.com'


def test_extract_links():
    links = _extract_links('Click https://example.com/one and https://example.com/two?x=1')
    assert links == ['https://example.com/one', 'https://example.com/two?x=1']
