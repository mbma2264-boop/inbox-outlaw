from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import RedirectResponse

from app.core.config import get_settings
from app.schemas import (
    ClassificationResult,
    EmailInput,
    GmailConnectionSummary,
    GmailOAuthStartResponse,
    GmailProfileResponse,
    GmailSyncResponse,
)
from app.services.classifier import classify_email
from app.services.gmail_client import (
    build_gmail_oauth_url,
    exchange_code_for_connection,
    fetch_latest_messages,
    fetch_profile,
)
from app.services.gmail_store import store

router = APIRouter(prefix="/api", tags=["api"])


@router.post("/classify", response_model=ClassificationResult)
def classify(email: EmailInput) -> ClassificationResult:
    return classify_email(email)


@router.get("/gmail/oauth/start", response_model=GmailOAuthStartResponse)
def gmail_oauth_start(
    redirect_to: str | None = Query(default=None, description="Optional frontend path after connection."),
) -> GmailOAuthStartResponse:
    try:
        authorization_url, state = build_gmail_oauth_url(redirect_to=redirect_to)
    except ValueError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return GmailOAuthStartResponse(
        authorization_url=authorization_url,
        state=state,
        note="OAuth URL generated. Use /api/gmail/oauth/login to redirect directly.",
    )


@router.get("/gmail/oauth/login")
def gmail_oauth_login(redirect_to: str | None = Query(default="/dashboard")) -> RedirectResponse:
    try:
        authorization_url, _ = build_gmail_oauth_url(redirect_to=redirect_to)
    except ValueError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return RedirectResponse(url=authorization_url, status_code=302)


@router.get("/gmail/oauth/callback")
async def gmail_oauth_callback(code: str | None = None, state: str | None = None) -> RedirectResponse:
    if not code or not state:
        raise HTTPException(status_code=400, detail="Missing OAuth code or state.")

    try:
        connection, state_data = await exchange_code_for_connection(code=code, state=state)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Google OAuth exchange failed: {exc}") from exc

    settings = get_settings()
    redirect_path = state_data.get("redirect_to") or "/dashboard"
    frontend_redirect_url = (
        f"{settings.frontend_origin}{redirect_path}"
        f"{'&' if '?' in redirect_path else '?'}connection_id={connection['connection_id']}"
    )
    return RedirectResponse(url=frontend_redirect_url, status_code=302)


@router.get("/gmail/connections", response_model=list[GmailConnectionSummary])
def gmail_connections() -> list[GmailConnectionSummary]:
    return [
        GmailConnectionSummary(
            connection_id=item["connection_id"],
            email_address=item["email_address"],
            scope=item.get("scope", ""),
            created_at=item["created_at"],
            updated_at=item["updated_at"],
        )
        for item in store.list_connections()
    ]


@router.get("/gmail/connections/{connection_id}/profile", response_model=GmailProfileResponse)
async def gmail_profile(connection_id: str) -> GmailProfileResponse:
    try:
        profile = await fetch_profile(connection_id)
        return GmailProfileResponse(
            email_address=profile.get("emailAddress", ""),
            messages_total=profile.get("messagesTotal"),
            threads_total=profile.get("threadsTotal"),
            history_id=profile.get("historyId"),
            raw=profile,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Failed to fetch Gmail profile: {exc}") from exc


@router.get("/gmail/connections/{connection_id}/sync", response_model=GmailSyncResponse)
async def gmail_sync(connection_id: str, limit: int = Query(default=10, ge=1, le=25)) -> GmailSyncResponse:
    try:
        connection = store.get_connection(connection_id)
        messages = await fetch_latest_messages(connection_id=connection_id, limit=limit)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Failed to fetch Gmail messages: {exc}") from exc

    return GmailSyncResponse(
        connection_id=connection_id,
        email_address=connection["email_address"],
        fetched_count=len(messages),
        messages=messages,
    )
