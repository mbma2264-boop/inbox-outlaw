from typing import Any, List, Literal, Optional

from pydantic import BaseModel, Field


Category = Literal[
    "Scam",
    "Likely Scam",
    "Personal",
    "Opportunity",
    "Verified Business",
    "Promotion",
    "Transactional",
    "Needs Review",
]


class EmailInput(BaseModel):
    sender_name: Optional[str] = None
    sender_email: str
    subject: str
    body_text: str
    links: List[str] = Field(default_factory=list)
    known_contact: bool = False
    in_reply_thread: bool = False
    starred: bool = False


class RuleMatch(BaseModel):
    rule_id: str
    weight: int
    reason: str


class ClassificationResult(BaseModel):
    category: Category
    risk_score: int = Field(ge=0, le=100)
    confidence_score: int = Field(ge=0, le=100)
    reasons: List[str]
    matched_rules: List[RuleMatch]
    recommended_action: str
    used_llm: bool = False


class GmailOAuthStartResponse(BaseModel):
    authorization_url: str
    state: str
    note: str


class GmailOAuthCallbackResponse(BaseModel):
    connection_id: Optional[str] = None
    email_address: Optional[str] = None
    frontend_redirect_url: Optional[str] = None
    note: str


class GmailConnectionSummary(BaseModel):
    connection_id: str
    email_address: str
    scope: str
    created_at: str
    updated_at: str


class SyncedEmail(BaseModel):
    id: str
    thread_id: Optional[str] = None
    label_ids: List[str] = Field(default_factory=list)
    history_id: Optional[str] = None
    snippet: str = ""
    subject: str = ""
    sender_name: Optional[str] = None
    sender_email: str = ""
    received_at: Optional[str] = None
    body_text: str = ""
    links: List[str] = Field(default_factory=list)
    classification: ClassificationResult


class GmailSyncResponse(BaseModel):
    connection_id: str
    email_address: str
    fetched_count: int
    messages: List[SyncedEmail]


class GmailProfileResponse(BaseModel):
    email_address: str
    messages_total: Optional[int] = None
    threads_total: Optional[int] = None
    history_id: Optional[str] = None
    raw: dict[str, Any] = Field(default_factory=dict)
