from __future__ import annotations

import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from app.core.config import get_settings


class GmailConnectionStore:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        settings = get_settings()
        self.path = settings.token_store_file
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _read(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"connections": {}, "states": {}}
        with self.path.open("r", encoding="utf-8") as handle:
            try:
                data = json.load(handle)
            except json.JSONDecodeError:
                data = {"connections": {}, "states": {}}
        data.setdefault("connections", {})
        data.setdefault("states", {})
        return data

    def _write(self, data: dict[str, Any]) -> None:
        with self.path.open("w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)

    def create_state(self, redirect_to: str | None = None) -> str:
        settings = get_settings()
        state = uuid4().hex
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=settings.oauth_state_ttl_seconds)
        with self._lock:
            data = self._read()
            data["states"][state] = {
                "redirect_to": redirect_to,
                "expires_at": expires_at.isoformat(),
            }
            self._write(data)
        return state

    def consume_state(self, state: str) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        with self._lock:
            data = self._read()
            state_data = data["states"].pop(state, None)
            self._write(data)
        if not state_data:
            raise ValueError("OAuth state was not found or was already used.")
        expires_at = datetime.fromisoformat(state_data["expires_at"])
        if expires_at < now:
            raise ValueError("OAuth state expired. Start the connection flow again.")
        return state_data

    def upsert_connection(
        self,
        *,
        email_address: str,
        access_token: str,
        refresh_token: str | None,
        token_expiry: str | None,
        scope: str,
        token_type: str | None,
    ) -> dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()
        with self._lock:
            data = self._read()
            existing = None
            for connection in data["connections"].values():
                if connection["email_address"].lower() == email_address.lower():
                    existing = connection
                    break
            connection_id = existing["connection_id"] if existing else uuid4().hex
            created_at = existing["created_at"] if existing else now
            stored_refresh = refresh_token or (existing.get("refresh_token") if existing else None)
            connection = {
                "connection_id": connection_id,
                "email_address": email_address,
                "access_token": access_token,
                "refresh_token": stored_refresh,
                "token_expiry": token_expiry,
                "scope": scope,
                "token_type": token_type,
                "created_at": created_at,
                "updated_at": now,
            }
            data["connections"][connection_id] = connection
            self._write(data)
            return connection

    def get_connection(self, connection_id: str) -> dict[str, Any]:
        data = self._read()
        connection = data["connections"].get(connection_id)
        if not connection:
            raise KeyError("Connection not found.")
        return connection

    def update_connection(self, connection_id: str, updates: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            data = self._read()
            connection = data["connections"].get(connection_id)
            if not connection:
                raise KeyError("Connection not found.")
            connection.update(updates)
            connection["updated_at"] = datetime.now(timezone.utc).isoformat()
            data["connections"][connection_id] = connection
            self._write(data)
            return connection

    def list_connections(self) -> list[dict[str, Any]]:
        data = self._read()
        connections = list(data["connections"].values())
        return sorted(connections, key=lambda item: item["updated_at"], reverse=True)


store = GmailConnectionStore()
