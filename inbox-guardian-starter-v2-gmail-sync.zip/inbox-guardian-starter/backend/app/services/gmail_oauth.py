from __future__ import annotations

import secrets
from urllib.parse import urlencode

from app.core.config import get_settings


GOOGLE_AUTH_BASE = "https://accounts.google.com/o/oauth2/v2/auth"


def build_gmail_oauth_url() -> tuple[str, str]:
    settings = get_settings()
    if not settings.google_client_id:
        raise ValueError("GOOGLE_CLIENT_ID is not configured.")

    state = secrets.token_urlsafe(24)
    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "response_type": "code",
        "access_type": "offline",
        "prompt": "consent",
        "scope": " ".join(settings.google_scope_list),
        "state": state,
        "include_granted_scopes": "true",
    }
    return f"{GOOGLE_AUTH_BASE}?{urlencode(params)}", state
