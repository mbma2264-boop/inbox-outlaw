from __future__ import annotations

import base64
import html
import re
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlencode

import httpx

from app.core.config import get_settings
from app.schemas import ClassificationResult, EmailInput, SyncedEmail
from app.services.classifier import classify_email
from app.services.gmail_store import store

GOOGLE_AUTH_BASE = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"
GMAIL_PROFILE_URL = "https://gmail.googleapis.com/gmail/v1/users/me/profile"
GMAIL_MESSAGES_URL = "https://gmail.googleapis.com/gmail/v1/users/me/messages"


def build_gmail_oauth_url(redirect_to: str | None = None) -> tuple[str, str]:
    settings = get_settings()
    if not settings.google_client_id:
        raise ValueError("GOOGLE_CLIENT_ID is not configured.")

    state = store.create_state(redirect_to=redirect_to)
    params = {
        "client_id": settings.google_client_id,
        "redirect_uri": settings.google_redirect_uri,
        "response_type": "code",
        "access_type": "offline",
        "prompt": "consent",
        "scope": " ".join(settings.google_scope_list),
        "state": state,
        "include_granted_scopes": "true",
    }
    return f"{GOOGLE_AUTH_BASE}?{urlencode(params)}", state


async def exchange_code_for_connection(code: str, state: str) -> tuple[dict[str, Any], dict[str, Any]]:
    settings = get_settings()
    if not settings.google_client_id or not settings.google_client_secret:
        raise ValueError("Google OAuth credentials are not fully configured.")

    state_data = store.consume_state(state)

    async with httpx.AsyncClient(timeout=30.0) as client:
        token_response = await client.post(
            GOOGLE_TOKEN_URL,
            data={
                "code": code,
                "client_id": settings.google_client_id,
                "client_secret": settings.google_client_secret,
                "redirect_uri": settings.google_redirect_uri,
                "grant_type": "authorization_code",
            },
            headers={"Accept": "application/json"},
        )
        token_response.raise_for_status()
        token_payload = token_response.json()

        access_token = token_payload["access_token"]
        userinfo_response = await client.get(
            GOOGLE_USERINFO_URL,
            headers={"Authorization": f"Bearer {access_token}"},
        )
        userinfo_response.raise_for_status()
        userinfo = userinfo_response.json()

    expiry = None
    expires_in = token_payload.get("expires_in")
    if isinstance(expires_in, int):
        expiry = (datetime.now(timezone.utc) + timedelta(seconds=expires_in)).isoformat()

    connection = store.upsert_connection(
        email_address=userinfo["email"],
        access_token=access_token,
        refresh_token=token_payload.get("refresh_token"),
        token_expiry=expiry,
        scope=token_payload.get("scope", ""),
        token_type=token_payload.get("token_type"),
    )
    return connection, state_data


async def get_valid_access_token(connection_id: str) -> str:
    connection = store.get_connection(connection_id)
    expiry_raw = connection.get("token_expiry")
    if expiry_raw:
        expires_at = datetime.fromisoformat(expiry_raw)
        if expires_at - datetime.now(timezone.utc) > timedelta(minutes=2):
            return connection["access_token"]

    refresh_token = connection.get("refresh_token")
    if not refresh_token:
        return connection["access_token"]

    settings = get_settings()
    async with httpx.AsyncClient(timeout=30.0) as client:
        refresh_response = await client.post(
            GOOGLE_TOKEN_URL,
            data={
                "client_id": settings.google_client_id,
                "client_secret": settings.google_client_secret,
                "refresh_token": refresh_token,
                "grant_type": "refresh_token",
            },
            headers={"Accept": "application/json"},
        )
        refresh_response.raise_for_status()
        payload = refresh_response.json()

    expiry = None
    expires_in = payload.get("expires_in")
    if isinstance(expires_in, int):
        expiry = (datetime.now(timezone.utc) + timedelta(seconds=expires_in)).isoformat()

    updated = store.update_connection(
        connection_id,
        {
            "access_token": payload["access_token"],
            "token_expiry": expiry,
            "scope": payload.get("scope", connection.get("scope", "")),
            "token_type": payload.get("token_type", connection.get("token_type")),
        },
    )
    return updated["access_token"]


async def fetch_profile(connection_id: str) -> dict[str, Any]:
    token = await get_valid_access_token(connection_id)
    async with httpx.AsyncClient(timeout=30.0) as client:
        response = await client.get(
            GMAIL_PROFILE_URL,
            headers={"Authorization": f"Bearer {token}"},
        )
        response.raise_for_status()
        return response.json()


async def fetch_latest_messages(connection_id: str, limit: int = 10) -> list[SyncedEmail]:
    token = await get_valid_access_token(connection_id)
    async with httpx.AsyncClient(timeout=30.0) as client:
        list_response = await client.get(
            GMAIL_MESSAGES_URL,
            params={"maxResults": max(1, min(limit, 25))},
            headers={"Authorization": f"Bearer {token}"},
        )
        list_response.raise_for_status()
        list_payload = list_response.json()
        messages = list_payload.get("messages", [])

        hydrated: list[SyncedEmail] = []
        for item in messages:
            message_id = item["id"]
            detail_response = await client.get(
                f"{GMAIL_MESSAGES_URL}/{message_id}",
                params={"format": "full"},
                headers={"Authorization": f"Bearer {token}"},
            )
            detail_response.raise_for_status()
            detail = detail_response.json()
            hydrated.append(_normalize_message(detail))

    return hydrated


def _normalize_message(message: dict[str, Any]) -> SyncedEmail:
    payload = message.get("payload", {}) or {}
    headers_map = _headers_to_map(payload.get("headers", []))
    parts = payload.get("parts", [])
    body_text = _extract_body_text(payload, parts)
    links = _extract_links(body_text)

    sender_name, sender_email = _parse_from_header(headers_map.get("From", ""))
    subject = headers_map.get("Subject", "")
    internal_date = message.get("internalDate")
    received_at = None
    if internal_date and str(internal_date).isdigit():
        received_at = datetime.fromtimestamp(int(internal_date) / 1000, tz=timezone.utc).isoformat()

    classification = classify_email(
        EmailInput(
            sender_name=sender_name,
            sender_email=sender_email or "unknown@example.com",
            subject=subject,
            body_text=body_text,
            links=links,
            known_contact=False,
            in_reply_thread=False,
            starred="STARRED" in (message.get("labelIds") or []),
        )
    )

    return SyncedEmail(
        id=message.get("id", ""),
        thread_id=message.get("threadId"),
        label_ids=message.get("labelIds") or [],
        history_id=message.get("historyId"),
        snippet=message.get("snippet", ""),
        subject=subject,
        sender_name=sender_name,
        sender_email=sender_email or "unknown@example.com",
        received_at=received_at,
        body_text=body_text[:4000],
        links=links,
        classification=classification,
    )


def _headers_to_map(headers: list[dict[str, str]]) -> dict[str, str]:
    return {item.get("name", ""): item.get("value", "") for item in headers}


def _parse_from_header(value: str) -> tuple[str | None, str | None]:
    match = re.match(r'(?:"?([^"]*)"?\s)?<?([^<>@\s]+@[^<>\s]+)>?', value)
    if not match:
        return None, None
    name = (match.group(1) or "").strip() or None
    email = (match.group(2) or "").strip() or None
    return name, email


def _extract_body_text(payload: dict[str, Any], parts: list[dict[str, Any]]) -> str:
    for mime_type in ("text/plain", "text/html"):
        content = _find_body_data(payload, parts, mime_type)
        if content:
            return _clean_text(content, is_html=(mime_type == "text/html"))
    return ""


def _find_body_data(payload: dict[str, Any], parts: list[dict[str, Any]], mime_type: str) -> str | None:
    if payload.get("mimeType") == mime_type:
        data = payload.get("body", {}).get("data")
        if data:
            return _decode_base64url(data)

    for part in parts or []:
        if part.get("mimeType") == mime_type:
            data = part.get("body", {}).get("data")
            if data:
                return _decode_base64url(data)

        nested = part.get("parts") or []
        nested_value = _find_body_data(part, nested, mime_type)
        if nested_value:
            return nested_value
    return None


def _decode_base64url(data: str) -> str:
    padded = data + "=" * (-len(data) % 4)
    decoded = base64.urlsafe_b64decode(padded.encode("utf-8"))
    return decoded.decode("utf-8", errors="ignore")


def _clean_text(value: str, *, is_html: bool) -> str:
    text = value
    if is_html:
        text = re.sub(r"<style.*?>.*?</style>", " ", text, flags=re.I | re.S)
        text = re.sub(r"<script.*?>.*?</script>", " ", text, flags=re.I | re.S)
        text = re.sub(r"<[^>]+>", " ", text)
        text = html.unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _extract_links(text: str) -> list[str]:
    return re.findall(r"https?://[^\s)>'\"]+", text)
