const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export default function GmailConnectCard() {
  const loginUrl = `${API_BASE}/api/gmail/oauth/login?redirect_to=/dashboard`;

  return (
    <div className="card">
      <h2>Connect Gmail</h2>
      <p>
        This starter now supports a real Google OAuth code exchange and can pull your
        latest Gmail messages into the dashboard for classification.
      </p>
      <a href={loginUrl} className="button" style={{ display: "inline-block", marginTop: 12 }}>
        Connect Gmail and fetch inbox
      </a>
      <p style={{ marginTop: 12, fontSize: 14, opacity: 0.8 }}>
        Tokens are stored only in a local JSON file for development. Replace this with
        encrypted database storage before production.
      </p>
    </div>
  );
}
