'use client';

import { useEffect, useState } from "react";

type RuleMatch = {
  rule_id: string;
  weight: number;
  reason: string;
};

type Classification = {
  category: string;
  risk_score: number;
  confidence_score: number;
  reasons: string[];
  matched_rules: RuleMatch[];
  recommended_action: string;
  used_llm: boolean;
};

type SyncedEmail = {
  id: string;
  thread_id?: string | null;
  label_ids: string[];
  history_id?: string | null;
  snippet: string;
  subject: string;
  sender_name?: string | null;
  sender_email: string;
  received_at?: string | null;
  body_text: string;
  links: string[];
  classification: Classification;
};

type SyncResponse = {
  connection_id: string;
  email_address: string;
  fetched_count: number;
  messages: SyncedEmail[];
};

type ProfileResponse = {
  email_address: string;
  messages_total?: number | null;
  threads_total?: number | null;
  history_id?: string | null;
};

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

function badgeClass(category: string) {
  if (category === "Scam") return "badge scam";
  if (category === "Likely Scam") return "badge likely";
  if (category === "Opportunity") return "badge opportunity";
  if (category === "Promotion") return "badge promo";
  if (category === "Transactional") return "badge transactional";
  if (category === "Personal") return "badge personal";
  return "badge";
}

export default function GmailInboxPreview({ connectionId }: { connectionId?: string }) {
  const [loading, setLoading] = useState(false);
  const [sync, setSync] = useState<SyncResponse | null>(null);
  const [profile, setProfile] = useState<ProfileResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    if (!connectionId) return;
    setLoading(true);
    setError(null);
    try {
      const [profileResp, syncResp] = await Promise.all([
        fetch(`${API_BASE}/api/gmail/connections/${connectionId}/profile`),
        fetch(`${API_BASE}/api/gmail/connections/${connectionId}/sync?limit=10`),
      ]);

      if (!profileResp.ok) throw new Error(`Profile request failed with ${profileResp.status}`);
      if (!syncResp.ok) throw new Error(`Sync request failed with ${syncResp.status}`);

      setProfile((await profileResp.json()) as ProfileResponse);
      setSync((await syncResp.json()) as SyncResponse);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unexpected sync error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
  }, [connectionId]);

  if (!connectionId) {
    return (
      <div className="card">
        <h2>Inbox preview</h2>
        <p>Connect Gmail first, then this page will fetch and classify your latest inbox messages.</p>
      </div>
    );
  }

  return (
    <div className="panel">
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
        <div>
          <h2>Latest Gmail messages</h2>
          <p>
            Connection: <strong>{connectionId}</strong>
            {profile?.email_address ? <> · {profile.email_address}</> : null}
          </p>
        </div>
        <button className="button" onClick={refresh} disabled={loading}>
          {loading ? "Refreshing..." : "Refresh inbox"}
        </button>
      </div>

      {error ? <p style={{ color: "#ff8ea1" }}>Error: {error}</p> : null}

      {profile ? (
        <div className="grid" style={{ marginBottom: 24 }}>
          <div className="card">
            <h3>Total messages</h3>
            <p>{profile.messages_total ?? "—"}</p>
          </div>
          <div className="card">
            <h3>Total threads</h3>
            <p>{profile.threads_total ?? "—"}</p>
          </div>
          <div className="card">
            <h3>History ID</h3>
            <p style={{ wordBreak: "break-all" }}>{profile.history_id ?? "—"}</p>
          </div>
        </div>
      ) : null}

      {sync?.messages?.length ? (
        <div style={{ display: "grid", gap: 16 }}>
          {sync.messages.map((message) => (
            <article key={message.id} className="card">
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
                <div>
                  <h3 style={{ marginBottom: 4 }}>{message.subject || "(No subject)"}</h3>
                  <p style={{ marginTop: 0 }}>
                    {message.sender_name ? `${message.sender_name} · ` : ""}
                    {message.sender_email}
                  </p>
                </div>
                <span className={badgeClass(message.classification.category)}>
                  {message.classification.category}
                </span>
              </div>

              <p>{message.snippet || message.body_text.slice(0, 180) || "No preview available."}</p>

              <div className="grid">
                <div className="card">
                  <h4>Scores</h4>
                  <p>Risk: {message.classification.risk_score}</p>
                  <p>Confidence: {message.classification.confidence_score}</p>
                  <p>Action: {message.classification.recommended_action}</p>
                </div>
                <div className="card">
                  <h4>Why</h4>
                  <ul>
                    {message.classification.reasons.map((reason) => (
                      <li key={reason}>{reason}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {message.links.length ? (
                <div>
                  <h4>Links</h4>
                  <ul>
                    {message.links.map((link) => (
                      <li key={link} style={{ wordBreak: "break-all" }}>{link}</li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </article>
          ))}
        </div>
      ) : connectionId && !loading ? <p>No messages loaded yet.</p> : null}
    </div>
  );
}
