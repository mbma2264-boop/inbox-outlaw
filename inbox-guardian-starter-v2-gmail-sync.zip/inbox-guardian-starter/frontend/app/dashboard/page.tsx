import Link from "next/link";
import ClassifierForm from "../../components/ClassifierForm";
import GmailInboxPreview from "../../components/GmailInboxPreview";

export default async function DashboardPage({
  searchParams,
}: {
  searchParams?: Promise<{ connection_id?: string }>;
}) {
  const params = (await searchParams) || {};
  const connectionId = params.connection_id;

  return (
    <main className="page">
      <div className="container">
        <div style={{ marginBottom: 16 }}>
          <Link href="/" className="button secondary">Back</Link>
        </div>

        <section className="hero">
          <h1>Dashboard</h1>
          <p>
            You can still test the raw classifier below, or connect Gmail and let the
            starter pull the latest messages for automatic classification.
          </p>
        </section>

        <section className="grid" style={{ marginBottom: 24 }}>
          <div className="card">
            <h3>Scams caught today</h3>
            <p>17</p>
          </div>
          <div className="card">
            <h3>Opportunities found</h3>
            <p>3</p>
          </div>
          <div className="card">
            <h3>Handled automatically</h3>
            <p>41</p>
          </div>
        </section>

        <GmailInboxPreview connectionId={connectionId} />
        <div style={{ height: 24 }} />
        <ClassifierForm />
      </div>
    </main>
  );
}
